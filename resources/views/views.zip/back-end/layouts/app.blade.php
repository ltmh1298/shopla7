@include('back-end.layouts.header')
<body>
	@yield('content')
@include('back-end.layouts.footer')