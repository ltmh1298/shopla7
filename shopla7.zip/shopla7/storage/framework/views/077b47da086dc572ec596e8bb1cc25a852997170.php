
<?php $__env->startSection('content'); ?>
<div class="log-w3">
<div class="w3layouts-main">
	<h2>Sign In Now</h2>
		<form action="<?php echo e(url('admin/home')); ?>" method="post">
			<div class=" "><?php echo e($error ?? ''); ?></div>
			<?php echo e(csrf_field()); ?>

			<input type="text" class="ggg" name="Username" placeholder="USERNAME" required="">
			<input type="password" class="ggg" name="Password" placeholder="PASSWORD" required="">
			<span><input type="checkbox" />Remember Me</span>
			<h6><a href="#">Forgot Password?</a></h6>
				<div class="clearfix"></div>
				<input type="submit" value="Sign In" name="login">
		</form>
		<p>Don't Have an Account ?<a href="registration.html">Create an account</a></p>
</div>
</div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopla7\resources\views/back-end/login.blade.php ENDPATH**/ ?>