
<?php $__env->startSection('content'); ?>
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="table-agile-info">
    <?php if(count($errors) > 0): ?>
					    <div class="alert alert-danger">
					        <ul>
					            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                <li><?php echo e($error); ?></li>
					            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        </ul>
					    </div>
					    <?php elseif( Session::get('massage') ): ?>
					    	<div class="alert alert-success">
						        <ul>
						            <?php echo Session::get('massage'); ?>	
						        </ul>
						    </div>
			<?php endif; ?>
 <div class="panel panel-default">
    <div class="panel-heading">
     Danh Sách Mục Sản Phẩm
     <a href="<?php echo url('admin/danhmuc/add'); ?>" title="" >
    <button type="button" class="btn btn-primary pull-right" style="margin: 11px 0 11px 0">Thêm mới danh mục</button></a>
    </div>
    
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>

        
        <thead>
          <tr>
            <th>ID</th>
            <th>Tên Danh Mục</th>
            <th>Action</th> 
          </tr>
        </thead>
       
        <tbody>
        <tr>
            <?php listcate ($data,$parent_id =0,$str=""); ?> 
        </tr> 
        </tbody>
      </table>
    </div>
  </div>
</div>
<!--main content end-->
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('back-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopla7\resources\views/back-end/category/cat-list.blade.php ENDPATH**/ ?>