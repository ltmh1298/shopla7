
<?php $__env->startSection('content'); ?>
<div class="col-sm-9 padding-right">
	
				<!--Sản Phẩm Mới-->
					<div class="features_items">
						<h2 class="title text-center"><?php echo $name_cat; ?></h2>
						<?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-sm-4">
								<div class="product-image-wrapper">
									<div class="single-products">
											<div class="productinfo text-center">
												<img src="<?php echo url('uploads/products/'.$row->images); ?>" alt="" />
												<h2><?php echo number_format($row->price); ?> VNĐ</h2>
												<p><?php echo $row->name; ?></p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
											<div class="product-overlay">
												<div class="overlay-content">
												<a href="<?php echo url($row->c_slug.'/'.$row->id.'-'.$row->slug); ?>" title="Xem chi tiết">
													<p> Khuyễn mãi</p>   
														<li><?php echo $row->promo1; ?></li> 
														<li><?php echo $row->promo2; ?></li> 
														<li><?php echo $row->promo3; ?></li>
													<h2><?php echo number_format($row->price); ?> VNĐ</h2>
													<h3><?php echo $row->name; ?></h3>
													<p> <?php echo $row->intro; ?></p>
												</a>
													<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
											</div>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div><!--Sản Phẩm mới-->
			
					
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopla7\resources\views/front-end/category/cat.blade.php ENDPATH**/ ?>