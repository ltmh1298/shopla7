<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
						<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($row->parent_id == 0): ?>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#<?php echo $row->slug; ?>">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											<?php echo $row->name; ?>

										</a>
									</h4>
								</div>
								<div id="<?php echo $row->slug; ?>" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($row2->parent_id == $row->id): ?>
												<li><a href="<?php echo url($row2->id.'-'.$row->slug); ?>"><?php echo $row2->name; ?> </a></li>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									</div>
								</div>
							</div>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div><!--/category-products-->
					
					</div>
				</div><?php /**PATH C:\xampp\htdocs\shopla7\resources\views/front-end/modules/left-menu.blade.php ENDPATH**/ ?>