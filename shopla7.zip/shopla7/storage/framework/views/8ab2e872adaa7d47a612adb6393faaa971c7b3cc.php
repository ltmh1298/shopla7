
<?php $__env->startSection('content'); ?>
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="form-w3layouts">
            <!-- page start-->
            <?php if(count($errors) > 0): ?>
					    <div class="alert alert-danger">
					        <ul>
					            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                <li><?php echo e($error); ?></li>
					            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        </ul>
					    </div>
					    <?php elseif( Session::get('massage')): ?>
					    	<div class="alert alert-success">
						        <ul>
						            <?php echo Session::get('massage'); ?>	
						        </ul>
						    </div>
			<?php endif; ?>
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            Thêm Danh Mục Mới
                        </header>
                        <div class="panel-body">
                            <div class="form">
                                <form class="cmxform form-horizontal " id="signupForm" method="post" action="<?php echo url('admin/danhmuc/add'); ?>"  novalidate="novalidate">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label for="input-id" class="col-lg-2">Danh mục cha</label>
                                        <div class="col-lg-12">
                                            <select name="sltCate" id="inputSltCate" class="form-control">
                                                <option value="0">- ROOT --</option>
                                                <?php MenuMulti($data,0,$str='---| ',old('sltCate')); ?>   		
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group ">
                                        <label for="name" class="col-lg-2">Tên Danh Mục</label>
                                        <div class="col-lg-12">
                                            <input class="form-control " id="txtCateName" name="txtCateName" type="text">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="col-lg-2">
                                            <button class="btn btn-primary" type="submit">Thêm Danh Mục</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <!-- page end-->
        </div>
<!--main content end-->
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('back-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopla7\resources\views/back-end/category/add.blade.php ENDPATH**/ ?>