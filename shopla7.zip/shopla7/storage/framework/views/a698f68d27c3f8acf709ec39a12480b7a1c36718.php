
<?php $__env->startSection('content'); ?>
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="table-agile-info">
    <?php if(count($errors) > 0): ?>
					    <div class="alert alert-danger">
					        <ul>
					            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                <li><?php echo e($error); ?></li>
					            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        </ul>
					    </div>
					    <?php elseif( Session::get('massage') ): ?>
					    	<div class="alert alert-success">
						        <ul>
						            <?php echo Session::get('massage'); ?>	
						        </ul>
						    </div>
			<?php endif; ?>
 <div class="panel panel-default">
    <div class="panel-heading">
    	<div class="col-lg-3">Chọn Mục Sản Phẩm</div>
		<div class="col-lg-6">
            <select name="sltCate" id="inputSltCate" class="form-control" style="margin: 11px 0 11px 0">
				<option value="0">-- ROOT --</option>
					<?php MenuMulti($cat,0,$str='---| ',$loai); ?>   		
            </select>
			<script>
				document.getElementById("inputSltCate").onchange = function() {
					if (this.selectedIndex!==0) {
						window.location.href = this.value;
					}        
				};
			</script>
        </div>
		<div class="col-lg-3">
			<?php if($loai !='all' ): ?>
     		<a href="<?php echo url('admin/sanpham/'.$loai.'/add'); ?>" title="" >
    		<button type="button" class="btn btn-primary pull-right" style="margin: 11px 0 11px 0">Thêm mới danh mục</button></a>
			<?php endif; ?>
		</div>
	</div>

    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>

        
        <thead>
          <tr>
            <th>ID</th>
            <th>Hình ảnh</th>
            <th>Tên sản phẩm</th>
            <th>Mục sản Phẩm</th>
            <th>Giá bán</th>
            <th>Trạng Thái</th>
            <th>Action</th> 
          </tr>
        </thead>
       
        <tbody>
        <tr>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo $pro->id; ?> </th>
			<th><img src="<?php echo url('uploads/products/'.$pro->images); ?>" width="50" height="40"> </th>
			<th><?php echo $pro->name; ?> </th>
			<th><?php echo $pro->category->name; ?> </th>
			<th><?php echo number_format($pro->price); ?> VNĐ</th>
			<th>
				<?php if($pro->status ==1): ?>
					<span style="color:blue">Còn hàng</span>
				<?php else: ?>
				<span style="color:red">Tạm hết hàng</span>
				<?php endif; ?>
			</th>
			<th>
				<a href="<?php echo url('admin/sanpham/edit/'.$pro->id); ?>" title="Sửa">
					<span class="glyphicon glyphicon-edit"></span></a>&nbsp;&nbsp;
				<a href="<?php echo url('admin/sanpham/del/'.$pro->id); ?>"  title="Xóa" onclick="return xacnhan('Xóa danh mục này ?')">
					<span class="glyphicon glyphicon-remove"></span> </a>
        </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
      </table>
    </div>
	<?php echo $data->render(); ?>

  </div>
</div>
<!--main content end-->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back-end.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopla7\resources\views/back-end/products/pro-list.blade.php ENDPATH**/ ?>